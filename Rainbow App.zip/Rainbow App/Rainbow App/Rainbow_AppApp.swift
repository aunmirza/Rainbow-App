//
//  Rainbow_AppApp.swift
//  Rainbow App
//
//  Created by Muhammad Aun e Ali Mirza on 08/10/24.
//

import SwiftUI

@main
struct Rainbow_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
