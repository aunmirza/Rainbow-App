//
//  ContentView.swift
//  Rainbow App
//
//  Created by Muhammad Aun e Ali Mirza on 08/10/24.
//

import SwiftUI

struct ContentView: View {
    @State var fun: String = "Hello thanks"
    
    
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack{
                Image(systemName: "rainbow")
                    .renderingMode(.original)
                    .resizable()
                    .scaledToFit()
                    .padding(24)
                    .symbolEffect(.variableColor
                        .reversing)
                
                Text(fun)
                    .foregroundStyle(.white)
                    .fontWeight(.semibold)
                    .padding(10)
                
                Button("Please Click") {
                    fun = "Apple Developer Academy"
                    
                }
                .padding()
                .foregroundStyle(.white)
                .background(.purple)
                .clipShape(RoundedRectangle(cornerRadius: 25))
                
                }
            
            }
        }
    
    }


#Preview {
    ContentView()
}
